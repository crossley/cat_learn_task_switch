% output data fields to txt file

load combined;
nr1 = 0; nr2=0; nr3=0; nr4=0; nr5=0; nr6=0; nr7=0; nr8=0;

for i=1:length(combined)
    this=combined(i);
    switch this.group
        case 1
            group = 'cj2ci';
            nr1=nr1+1;
            nr=nr1;
        case 2
            group = 'cj2cr';
            nr2=nr2+1;
            nr=nr2;
        case 3
            group = 'cj4cr';
            nr3=nr3+1;
            nr=nr3;
        case 4
            group = 'ii2ci';
            nr4=nr4+1;
            nr=nr4;
        case 5
            group = 'ii2cr';
            nr5=nr5+1;
            nr=nr5;
        case 6
            group = 'ii4cr';
            nr6=nr6+1;
            nr=nr6;
        case 7
            group = 'cj4ci';
            nr7=nr7+1;
            nr=nr7;
        case 8
            group = 'ii4ci';
            nr8=nr8+1;
            nr=nr8;
    end
    data=[this.stim(:,1:4) this.respCat' this.rtCat'];
    fname = [group 'sub' num2str(nr) '.txt'];
    fid = fopen(fname,'wt');
    fprintf(fid, '%2.0f %6.2f %5.2f %2.0f %2.0f %5.2f\n', data');
    fclose(fid);
end

