% combine all data structures into one big structure
% output data fields to txt file

group=cd;
group(1:29)=[];

d = what;

for i=1:length(d.mat)
    load(d.mat{i});
    data=[this.stim(:,1:4) this.respCat' this.rtCat'];
    fname = [group 'sub' num2str(i) '.txt'];
    fid = fopen(fname,'wt');
    fprintf(fid, '%2.0f %6.2f %5.2f %2.0f %2.0f %5.2f\n', data');
    fclose(fid);
end

